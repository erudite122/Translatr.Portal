﻿namespace Translatr.Portal
{
    public class PortalConsts
    {
        public const string LocalizationSourceName = "Portal";
    }
}